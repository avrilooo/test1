create view emp_view as
select `bjpowernode`.`emp_2`.`EMPNO` AS `empno`, `bjpowernode`.`emp_2`.`ENAME` AS `ename`
from `bjpowernode`.`emp_2`;

